package com.kodilla.rps;

public class Paper implements Type {
}
