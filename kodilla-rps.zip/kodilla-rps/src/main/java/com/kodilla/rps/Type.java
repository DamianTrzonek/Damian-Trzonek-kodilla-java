package com.kodilla.rps;

public interface Type {
}
