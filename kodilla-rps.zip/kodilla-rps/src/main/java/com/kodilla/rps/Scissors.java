package com.kodilla.rps;

public class Scissors implements Type {
}
