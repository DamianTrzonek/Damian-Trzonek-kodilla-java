package com.kodilla.rps;

public class Rock implements Type {
}
