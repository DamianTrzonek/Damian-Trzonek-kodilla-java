package com.kodilla.rps;

import java.util.Scanner;

public class Player {
   private String name;
   private int wins = 0;
   private String choice;
   private Type play;

    public void play() {
        Scanner sc = new Scanner(System.in);
        choice = sc.nextLine();
        if (choice.equals("1") ) {
            play = new Rock();
            System.out.println("You played ROCK");
        } else if (choice.equals("2")) {
             play = new Paper();
            System.out.println("You played PAPER");
        } else if (choice.equals("3")) {
             play = new Scissors();
            System.out.println("You played SCISSORS");
        } else {
            System.out.println("You have to choose from numbers 1 to 3!");
        }
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getChoice() {
        return choice;
    }

    public Type getPlay() {
        return play;
    }

    public void playerWins() {
        wins =+ 1;
    }

    public void resetWins() {
        wins = 0;
    }
}

