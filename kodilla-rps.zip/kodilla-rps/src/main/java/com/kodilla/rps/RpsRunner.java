package com.kodilla.rps;

public class RpsRunner {
    public static void main(String[]args){
boolean end = false;

        Game game = new Game();
        Validator val = new Validator();
        game.welcome();
        game.setName();
        game.setRounds();
while(!end) {
    game.startRound();
    val.checkChoice();
    game.gameEnds();
}
    }
}