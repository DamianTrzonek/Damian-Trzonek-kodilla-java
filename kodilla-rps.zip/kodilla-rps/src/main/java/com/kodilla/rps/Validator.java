package com.kodilla.rps;

public class Validator {
    Computer computer;
    Player player;

    public void checkChoice() {
        Type choice = player.getChoice();
        if(player.getPlay().equals(new Rock()) && computer.getComputerChoice().equals(new Rock())) {
            System.out.println("DRAW!");
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());
        } else if(player.getPlay().equals(new Rock()) && computer.getComputerChoice().equals(new Paper())) {
            System.out.println(Computer.COMPUTER + " WINS!");
            computer.computerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Rock()) && computer.getComputerChoice().equals(new Scissors())) {
            System.out.println(player.getName() + " WINS!");
            player.playerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Paper()) && computer.getComputerChoice().equals(new Rock())) {
            System.out.println(player.getName() + " WINS!");
            player.playerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Paper()) && computer.getComputerChoice().equals(new Paper())) {
            System.out.println("DRAW!");
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Paper()) && computer.getComputerChoice().equals(new Scissors())) {
            System.out.println(Computer.COMPUTER + " WINS!");
            computer.computerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Scissors()) && computer.getComputerChoice().equals(new Rock())) {
            System.out.println(Computer.COMPUTER + " WINS!");
            computer.computerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Scissors()) && computer.getComputerChoice().equals(new Paper())) {
            System.out.println(player.getName() + " WINS!");
            player.playerWins();
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());

        } else if(player.getPlay().equals(new Scissors()) && computer.getComputerChoice().equals(new Scissors())) {
            System.out.println("DRAW!");
            System.out.println(player.getName() + player.getWins() + " - " + Computer.COMPUTER + computer.getWins());
        } else {
            System.out.println("Invalid input. Try again.");
    }
    }

}