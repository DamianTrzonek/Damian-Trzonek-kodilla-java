package com.kodilla.rps;

import java.util.Random;

public class Computer {

    public static final String COMPUTER = "COMPUTER";
    private int wins = 0;
    private Type computerChoice;

    public Type makeMove() {
        Random random = new Random();
        int computerChoosesNumber = random.nextInt(3) + 1;
        switch (computerChoosesNumber) {
            case 1:
                System.out.println(COMPUTER + " played ROCK");
                computerChoice = new Rock();
                break;
            case 2:
                System.out.println(COMPUTER + " played PAPER");
                computerChoice = new Paper();
                break;
            case 3:
                System.out.println(COMPUTER + " played SCISSORS");
                computerChoice = new Scissors();
                break;
        }
        return computerChoice;
    }

    public Type getComputerChoice() {
        return computerChoice;
    }

    public int getWins() {
        return wins;
    }

    public void computerWins() {
        this.wins += 1;
    }

    public void resetWins() {
        this.wins = 0;
    }
}
