package com.kodilla.rps;

import java.util.Scanner;

public class Game {
    Player player = new Player();
    Computer computer = new Computer();
    private boolean end = false;
    private Scanner sc = new Scanner(System.in);
    private int numberOfWins;
    private String choice;

    public void welcome() {
        System.out.println("Welcome to Rock, Paper, Scissors game!");
    }

    public void setName() {
        System.out.println("Please enter your name.");
         player.setName(sc.nextLine());
        while (player.getName() == null || player.getName().equals("")) {
            System.out.println("Please enter your name.");
            player.setName(sc.nextLine());
        }
        System.out.println("Hello " + player.getName());
    }

    public void setRounds() {
        System.out.println("Until how many wins would you like to play?");
            numberOfWins = sc.nextInt();
            while (numberOfWins <= 0) {
                System.out.println("Invalid input. Try again.");
                numberOfWins = sc.nextInt();
            }
            System.out.println("Thanks. Your number of rounds is: " + numberOfWins);
        }

    public void rules() {
        System.out.println("Here are the rules: \n" + "1 - play rock \n" +
                "2 - play paper \n" +
                "3 - play scissors \n" +
                "x - finish game \n" +
                "n - new game");
    }

    public void startRound() {
        rules();
        System.out.println("Please make your move.");
        choice = player.getChoice();
    }

    /*public void checkScore() {
        Type computerMove = computer.makeMove();
        switch (choice) {
            case "1":
                System.out.println("You played ROCK");
                if (computerMove == Computer.ROCK) {
                    System.out.println("DRAW!");
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else if (computerMove == Computer.PAPER) {
                    System.out.println("You LOST!");
                    computer.computerWins();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else {
                    System.out.println("You WON!");
                    playerWin();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                }
                break;
            case "2":
                System.out.println("You played PAPER");
                if (computerMove == Computer.ROCK) {
                    System.out.println("You WON!");
                    playerWin();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else if (computerMove == Computer.PAPER) {
                    System.out.println("DRAW!");
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else {
                    System.out.println("You LOST!");
                    computer.computerWins();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                }
                break;
            case "3":
                System.out.println("You played SCISSORS");
                if (computerMove == Computer.ROCK) {
                    System.out.println("You LOST!");
                    computer.computerWins();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else if (computerMove == Computer.PAPER) {
                    System.out.println("You WON!");
                    playerWin();
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                } else {
                    System.out.println("DRAW!");
                    System.out.println("You " + playerWins + " - " + "Computer " + computer.getWins());
                }
                break;
            default:
                System.out.println("Not valid option");
        }
    }*/



    public void gameEnds() {
        if (computer.getWins() == numberOfWins) {
            System.out.println("Computer WON the Game!");
            System.out.println("x - finish game \n" +
                    "n - new game");
            sc.nextLine();
            if (sc.nextLine() == "n") {
                newGame();
            } else if (sc.nextLine() == "x") {
                System.out.println("Do you really want to end the game?Press 'x' again to exit game");
                sc.nextLine();
                if (sc.nextLine() == "x") {
                    end = true;
                    System.exit(0);
                }
            } else if (player.getWins() == numberOfWins) {
                System.out.println(player.getName() + " WON THE GAME, CONGRATULATIONS!");
                System.out.println("x - finish game \n" +
                        "n - new game");
                sc.nextLine();
                if (sc.nextLine() == "n") {
                    newGame();
                } else if (sc.nextLine() == "x") {
                    System.out.println("Do you really want to end the game?Press 'x' again to exit game");
                    sc.nextLine();
                    if (sc.nextLine() == "x") {
                        end = true;
                        System.exit(0);
                    }
                }
            }
        }
    }
    public void newGame() {
        welcome();
        setName();
        setRounds();
        player.resetWins();
        computer.resetWins();
        startRound();
    }
}
